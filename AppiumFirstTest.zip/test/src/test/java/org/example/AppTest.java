package org.example;


import io.appium.java_client.AppiumDriver;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

public class AppTest 
{
    private AppiumDriver appiumDriver;
    private DesiredCapabilities desiredCapabilities;
    @BeforeClass
    public void setup() throws MalformedURLException {
        //WebDriverManager wdm = WebDriverManager.chromedriver();
        //wdm.setup();
        //String chromedriverPath = wdm.getDownloadedDriverPath();
        desiredCapabilities = new DesiredCapabilities();
        desiredCapabilities.setCapability("deviceName","sdk_gphone64_x86_64");
        //desiredCapabilities.setCapability("automationName","UiAutomator1");
        desiredCapabilities.setCapability("noReset ",true);
        desiredCapabilities.setCapability("udid","emulator-5554");
        desiredCapabilities.setCapability("platformName","Android");
        desiredCapabilities.setCapability("platformVersion","12");
        desiredCapabilities.setCapability("appPackage","com.google.android.calculator");
        desiredCapabilities.setCapability("appActivity","com.android.calculator2.Calculator");
        //desiredCapabilities.setCapability("chromedriverExecutable",chromedriverPath);
        //desiredCapabilities.setCapability("browserName", "chrome");
        appiumDriver = new AppiumDriver(new URL("http://localhost:4723/wd/hub"),desiredCapabilities);
        appiumDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        System.out.println("Application Started");
    }

    @Test
    public void testWithAppium()
    {
        System.out.println("executed");
    }
}
